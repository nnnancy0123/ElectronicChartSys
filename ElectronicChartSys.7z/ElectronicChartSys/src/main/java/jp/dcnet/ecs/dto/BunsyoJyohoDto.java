package jp.dcnet.ecs.dto;

import lombok.Data;

@Data
public class BunsyoJyohoDto {

	private String ishiId;

	private String password;

}
