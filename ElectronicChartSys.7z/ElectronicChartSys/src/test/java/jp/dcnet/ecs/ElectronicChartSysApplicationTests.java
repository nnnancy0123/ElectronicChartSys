package jp.dcnet.ecs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectronicChartSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
